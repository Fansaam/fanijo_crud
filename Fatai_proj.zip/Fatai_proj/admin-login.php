<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>
<article class="sub_body" style="background:#fff url(images/green.jpg)">

	<div id="top" style="z-index:1; top:0px;
    position:fixed;margin-left:190px">
		<div class="center">
			<ul>
			<li><span class='phone'><a  href="student-login.php"> Login Page</a></span> </li>
				<li> <a href="#" style="font-size:17px">  </a> </li>
				<li> <a href="#" style="font-size:17px"></a> </li>
				
				<li><span class='phone'>Welcome, </span>&nbsp; Student </li>
			</ul>
		</div>
	</div>
	
		<br>
		<!-- navigation block  -->
		<div class="center">
		<div id="logosearch" style="background-color:white;height:100px;color:green" class="wow animated zoomIn">
			<div class="logo wow animated fadeInDown"><h1><img src="Images/fuoye-logo.png" width="100" height="100"></h1></div>
			<div class="logo wow animated fadeInUp"><h1 style="margin-left:95px;margin-top:-50px;font-family:times"><strong style="font-size:40px">C</strong>omputer<br><strong style="font-size:40px">E</strong>ngineering<br><p style="font-size:15px">www.cpefuoye.com</p></h1></div>	
			
		</div>
		
		
		<!-- navigation block  -->
		<ul id="navconteiner" class="wow animated fadeInRight">			
			<li> <a href="index.php">HOME</a> </li>
			<li> <a href="student-login.php" >STUDENTS' LOGIN</a> </li>
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li class="active"> <a href="admin-login.php">ADMIN LOGIN</a> </li>
			<li> <a href="result.php">VIEW RESULTS</a> </li>
			<li> <a href="#">CONTACT US</a> </li>
		</ul>
	
	</div>	

	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
	<div id="sl_b_box">					
		
	</div>
	<!-- end of fast blog's link block   -->

	

	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:white;height:auto;width:100%">
						<div class="boxed">

<h2 style="margin-top:0px; height:30px; background-color:green;text-align:center;border-radius:60px;font-family:times">Nacomes Admin Login Page</h2>


</div>





			<br>

<form method="post">
  <fieldset style="background-color:green;text-align:center;border-radius:60px">
 
    <br>
    
    <br>
<fieldset><legend style="color:white">Enter Your Admin Username</legend>
     Admin Username:
   &nbsp;&nbsp;&nbsp; <input style="align:left;border-radius:60px;width:320px";  type="text" placeholder="Enter Your Username Only" name="username"  value=""> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br>
<br>
    
      
<br>
  &nbsp;&nbsp;<input class="readmore" style="border-radius:60px;width:100px;color:green;background-color:white" type="submit" name="submit" value="Submit" style="align:center">
</fieldset>

  
    <br>
    <br>
    <br>
     <fieldset style="background-color:white;text-align:center;border-radius:60px;height:50px;color:red">

        <i>Are you a Student?</i> <a  class="readmore" href="student-login.php" style="float:center;height:40px;width:130px;">Go to Student Login</a>
  </fieldset>
    <br>
    
    <br>
    <br>
    <br>
    
  </fieldset>
</form>

<br>





			</div>
			


		
		</div>
		
	</div>





<?php
include('database.php');
    
  if(isset($_POST['submit']))
  {

   $username=$_POST['username'];


    $query = "SELECT username FROM admin WHERE username='$username'";
       $result = mysql_query($query);
       $count = mysql_num_rows($result);

$id=$row['username'];
if ($count > 0)

{

echo "<script>alert('Login Authorized.. Welcome to the Admin Session of Nacomes Online Voting System'); window.location='admin.php'</script>";


}
else
{
echo "<script>alert('Sorry! Your Identity As Admin Could Not Be Verified'); window.location='admin-login.php'</script>";

}

}
                     ?>













	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li class="active"><a href="admin-login.php">ADMIN' LOGIN</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li><a href="admin.php">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		<div id="foot2">
			<div class="center">				
				
		</div>
	</footer>
<script src="js/script.js"></script>
</article>
</html>
