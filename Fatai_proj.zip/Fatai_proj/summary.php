<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>
<body class="sub_body">
<?php
include('session.php');
	include('database.php');
	$user_query=mysql_query("select * from all_user where matricnumber='$id_session'")or die(mysql_error());
	$row=mysql_fetch_array($user_query); {
?>
	<div id="top" style="z-index:1; top:0px;
    position:fixed;margin-left:190px">
		<div class="center">
			<ul>
			<li><span class='phone'><a  href="logout.php"> Logout</a></span> </li>
				<li> <a href="#" style="font-size:17px"> <?php echo $row['matricnumber']?> </a> </li>
				<li> <a href="#" style="font-size:17px"><?php echo $row['lastname'];?>, <?php echo $row['middlename'];?>&nbsp; <?php echo $row['firstname'] ?></a> </li>
				
				<li><span class='phone'>Welcome,</span> </li>
			</ul>
		</div>
	</div>
	
		<br>
		<!-- navigation block  -->
		<div id="foot1">
			<div class="center">
				<ul>
				<li class="logo" style="margin-top:-35px"><img src="Images/capture.png" width="290" height="100" ></li>

					<li ><a href="index.php">HOME</a></li>
					
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li> <a href="#">ADMIN LOGIN</a> </li>
			<li class="active"> <a href="result.php">VIEW RESULTS</a> </li>
			
					
				</ul>
			</div>
		</div>
	<!-- end of fast blog's link block   -->
	

<div class="flex-container subpage">
	<!-- flex slider block  -->
		<div class="min_height solutions1 wow animated fadeInLeft">	
			
		</div>
	</div>
	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
	<div id="sl_b_box">					
		<div id="sl_b_container" class="wow animated zoomOut">
			<div id="sl_b_content1"> <a href="#">Register Now</br>To Be Eligible To Vote</a> </div>
			<div id="sl_b_content2"> <a href="#">Are You Registered?</br>Cast Your Vote Now</a> </div>
			<div id="sl_b_content3"> <a href="#">View Voting Results</br>Live Results Updates</a> </div>
		</div>
	</div>

	

	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:green;width:955px">
		
			<h2 style="float:left;font-family:times"><i>Hello</i><b style="font-family:arial;font-size:25px">  <?php echo $row['middlename'];?>&nbsp;</b>, <i>Below Is The Summary Of The Votes You Casted</i></h2>
			<br><br>
<?php } ?>
<?php

	include('database.php');
	$user_query=mysql_query("select * from presidency where matricnumber='$id_session'")or die(mysql_error());
	$user_query2=mysql_query("select * from vice_presidency where matricnumber='$id_session'")or die(mysql_error());
	$user_query3=mysql_query("select * from gensec where matricnumber='$id_session'")or die(mysql_error());
	///$user_query4=mysql_query("select * from treasurer_votes where matricnumber='$id_session'")or die(mysql_error());
	$row=mysql_fetch_array($user_query);
	$row2=mysql_fetch_array($user_query2);
	$row3=mysql_fetch_array($user_query3);
	//$row4=mysql_fetch_array($user_query4); {

?>
			<div class="row services-row services-row-head services-row-1">
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"">
                    <div class="services-group wow animated fadeInLeft" data-wow-offset="40" style="background-color:white">
                        <h1  style="color:green"> PRESIDENCY:   You Voted <a style="color:orange"><?php echo $row['voted_candidate']?></a> <img src="images/voted.jpg" height="50" width="90"></h1><br><br><br>
                        <h1  style="color:green"> VICE-PRESIDENCY:   You Voted <a style="color:orange"><?php echo $row2['voted_candidate']?></a> <img src="images/voted.jpg" height="50" width="90"></h1> <br><br><br>
                       <h1  style="color:green">  GENERAL SECRETARY:    You Voted <a style="color:orange"><?php echo $row3['voted_candidate']?> </a><img src="images/voted.jpg" height="50" width="90"></h1> <br><br><br>
                  
                                         
                    </div>
                </div>
        <br><br>
        <p style="align:center">
                        <a href="result.php"><button type="submit" class="btn btn-primary-green" style="background-color:white;color:green;height:30px;font-size:20px;margin-left:355px;">Click To View Results Update</button></a>
                    </p>

               
        
              

            </div>
			</div>
			


			
			

<?php


$con = mysqli_connect("localhost","root","","nacomes");



if(isset($_POST['isife']))

{
	  $query = "SELECT matricnumber FROM vice_presidency  WHERE matricnumber='$id_session'";
       $result = mysql_query($query);
       $anything_found = mysql_num_rows($result);
	if ($anything_found)

		{
echo "<script>alert('Hello! Sorry, You Can Only Vote For Vice Presidency Once');window.location='vote3.php'</script>";

}
else{
 $vote_isife = "UPDATE vice_president set isife=isife+1";
$update=mysql_query("INSERT INTO vice_presidency(matricnumber, voted_candidate)VALUES('$id_session', 'Isife OlisaEmeka Fredrick')");
$update2=mysql_query("INSERT INTO isife(matricnumber)VALUES('$id_session')");
	$run_isife = mysqli_query($con, $vote_isife);
	
	

	echo "<script>alert('You Have Successfully Casted Your Vote For Isife OlisaEmeka Fredrick');window.location='vote3.php'</script>";

	
}
}





if(isset($_POST['gbenga']))

{
	 $query = "SELECT matricnumber FROM vice_presidency WHERE matricnumber='$id_session'";
       $result = mysql_query($query);
       $anything_found = mysql_num_rows($result);
	if ($anything_found)

		{
echo "<script>alert('Hello! Sorry, You Can Only Vote For Vice Presidency Once');window.location='vote3.php'</script>";

}
else{
 $vote_gbenga = "UPDATE vice_president set gbenga=gbenga+1";
$update=mysql_query("INSERT INTO presidency(matricnumber, voted_candidate)VALUES('$id_session', 'Olufeyimi Olugbenga Olatunde')");
$update2=mysql_query("INSERT INTO gbenga(matricnumber)VALUES('$id_session')");
	$run_gbenga = mysqli_query($con, $vote_gbenga);

	echo "<script>alert('You Have Successfully Casted Your Vote For Olufeyimi Olugbenga Olatunde');window.location='vote3.php'</script>";

	
}
}







?>




			

				


		</div>
		
	</div>
	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li class="active"><a href="vote">HOME</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li><a href="#">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		<div id="foot2">
			<div class="center">				
				
			</div>
		</div>
	</footer>
<script src="js/script.js"></script>
</body>
</html>
