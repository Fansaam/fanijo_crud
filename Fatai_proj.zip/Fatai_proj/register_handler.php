<?php
 ob_start();
  include('database.php');
    require('session.php');
  if(isset($_POST['submit']))
  {

    $matricnumber=mysql_real_escape_string($_POST['matricnumber']);
    $query = "SELECT matricnumber FROM all_user WHERE matricnumber='$matricnumber';";
       $result = mysql_query($query);
       $anything_found = mysql_num_rows($result);


if ($anything_found>0)

{
echo "<script>alert('Hello! It Seems You've Registered Once, If You Wish To Update Your Details though, You Can do so via the Update Info page you are being redirected to..');window.location='profile_update.php'</script>";

}

 

else

  {

      $lastname= $_POST['lastname'];
  $firstname= $_POST['firstname'];
  $middlename= $_POST['middlename'];
  $sex= $_POST['sex'];
  $status= $_POST['status'];
   $department= $_POST['department'];
  $level=empty($_POST['level']) ? '' : $_POST['level'];

  $matricnumber=empty($_POST['matricnumber']) ? '' : $_POST['matricnumber'];
 
  

  $update=mysql_query("INSERT INTO all_user(lastname, firstname, middlename, sex, status, department, level, matricnumber, username, password, vote_status) VALUES('$lastname', '$firstname','$middlename','$sex','$status','$department', '$level','$matricnumber','$matricnumber','$matricnumber', 'unvoted')");

    if($update)
                                        {
                                            echo "<script>alert('Hello! You Have Successfully Enrolled To Vote. You Can Proceed To The Voting Page.');window.location='vote.php'</script>";
                                        }
                                        
                                       else
                                        {
                                          echo "<script>alert('Hey! It Seems Something Went Wrong');window.location='register.php'</script>";
                                        }
                                      }



                                    }
                                       ob_end_flush();
                                      ?>
