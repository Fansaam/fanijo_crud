<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>
<body class="sub_body" style="background:#fff url(images/green.jpg)">

	<div id="top">
		<div class="center">
			<ul>
				<li> <a href="register.php">Register</a> </li>
				<li> <a href="student-login.php">Log In</a> </li>
			
			</ul>
		</div>
	</div>
	<div class="center">
		<div id="logosearch" style="background-color:white;height:100px;color:green" class="wow animated zoomIn">
			<div class="logo wow animated fadeInDown"><h1><img src="Images/fuoye-logo.png" width="100" height="100"></h1></div>
			<div class="logo wow animated fadeInUp"><h1 style="margin-left:95px;margin-top:-50px;font-family:times"><strong style="font-size:40px">C</strong>omputer<br><strong style="font-size:40px">E</strong>ngineering<br><p style="font-size:15px">www.cpefuoye.com</p></h1></div>	
			
		</div>
		
		<!-- navigation block  -->
		<ul id="navconteiner" class="wow animated fadeInRight">			
			<li > <a href="index.php">HOME</a> </li>
			<li class="active"> <a href="register.php" >REGISTER</a> </li>
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li> <a href="#">ADMIN LOGIN</a> </li>
			<li> <a href="#">VIEW RESULTS</a> </li>
			<li> <a href="#">CONTACT US</a> </li>
		</ul>
		<!-- end of navigation  -->
	</div>	
	<div class="flex-container subpage">
	<!-- flex slider block  -->
		<div class="min_height solutions2 wow animated fadeInLeft">	
			<h6 class="wow animated zoomIn" style="color:green;font-size:27px;float:right;margin-top:170px;margin-right:550px;font-family:times"><strong style="font-size:35px" class="wow animated fadeInLeft">As NACOMES Member</strong></h6>
		</div>
	</div>
	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
	<div id="sl_b_box">					
		<div id="sl_b_container" class="wow animated zoomIn">
			<div id="sl_b_content1"> <a href="#">Register Now</br>To Be Eligible To Vote</a> </div>
			<div id="sl_b_content2"> <a href="#">Are You Registered?</br>Cast Your Vote Now</a> </div>
			<div id="sl_b_content3"> <a href="#">View Voting Results</br>Live Results Updates</a> </div>
		</div>
	</div>




<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:white;height:600px">
			


			<div class="boxed">

<h2 style="margin-top:0px; height:30px; background-color:green;text-align:center;border-radius:60px;font-family:times">Students' Voting Registration Page</h2>


</div>

<form method="post">
  <fieldset style="background-color:green;text-align:center;border-radius:60px">
  <br>
  <br>
    <legend style="text-align:center;color:black;font-size:20px">Sign-Up Information</legend>
    <fieldset><legend style="color:white">Personal Information</legend>
    &nbsp;&nbsp;&nbsp;Last Name:
    <input style="align:left;border-radius:60px"; type="text" placeholder="Surname" name="lastname" value="" required> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; First Name: <input type="text" style="border-radius:60px" placeholder="Firstname" name="firstname" required>
<br>
<br>
    
    Mid-Name:
    <input type="text" style="border-radius:60px" name="middlename" placeholder="Middle Name" value="" required> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gender: <input type="text" style="border-radius:60px" name="sex" placeholder="Sex" required>
    <br><br>
    <br>
    E-mail: <input type="text" style="border-radius:60px" name="email" placeholder="E-mail address" required>
    </fieldset>
    <br>
    <br>
    
    <br>
<fieldset><legend style="color:white">Other Information</legend>
     Status:
   &nbsp;&nbsp;&nbsp; <input style="align:left;border-radius:60px"; type="text" placeholder="Staff Or Student?" name="status"  value="Student" readonly> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Department: <input type="text" style="border-radius:60px" placeholder="Department" name="department" value="Computer Engineering" readonly> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<br>
<br>
    
    Level:
    <input type="text" style="border-radius:60px" name="level" placeholder="Academic Level" value="" required>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Matric number: <input type="text" style="border-radius:60px" name="matricnumber" placeholder="Matric Number" required>
    <br><br>

    Password: <input type="password" style="border-radius:60px" name="password" placeholder="Enter your Password" required>
    <br>
    <br>
    <br>
    
</fieldset>

    &nbsp;&nbsp;<input style="border-radius:60px" type="submit" name="submitt" value="Sign-Up" style="align:center">
    <br>
    <br>
    <br>
    <br>
    
    <br>
    <br>
    <br>
    <br>
  </fieldset>
</form>


				
			<div class="row services-row services-row-head services-row-1">
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"">
                    <div class="services-group wow animated fadeInLeft" data-wow-offset="40" style="background-color:green">
                        
                        
                        
                    </div>
                </div>
        
               

            </div>
			</div>
			



<div class="equalcolumn" style="background-color:white;color:green;height:600px;width:330px">
			
			
				<p class="smallerp">
					 <form  method="post">
                <fieldset style="height:180px"><legend style="text-align:center"><h2 style="color:green;text-align:center">Cast Your Votes</h2></legend>
                <h3 style="text-align:center;color:green;font-size:19px"><strong style="color:red;font-size:23px">NOTE:</strong> Your Matric Number Is Your Username</h3><br><br>
                     <a  class="readmore" href="student-login.php" style="margin-left: 20px; align:center;float:center;height:40px;width:260px;font-size:20px;text-align:center">Click Here To LOGIN</a>
                   
                    </p>
                </fieldset>
            </form>

				</p>

			<div class="clear"></div>

			<div class="clear"></div> <div class="clear"></div> <div class="clear"></div>
			<h2 style="color:green">About Nacomes</h2>
			<img src="images/cpelogo.jpg" width="250" height="150" alt=""/>
				<p class="smallerp" style="font-size:15px;color:green">
					Nacomes, an acronym which stands for "National Association Of Computer Engineering Student" is an official student association whose sole aim is to help unify students together, most importantly socially and academically. The essence of this association becomes obvious when... <br />
					<a class="readmore" href="#">Read More</a>
				</p>

				
				


		</div>
		
	</div>
	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li class="active"><a href="register.php">REGISTER</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li><a href="#">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		<div id="foot2">
			<div class="center">				
				
			</div>
		</div>
	</footer>



<?php
 ob_start();
  include('database.php');
   
  if(isset($_POST['submitt']))
  {

    $matricnumber=mysql_real_escape_string($_POST['matricnumber']);
    $query = "SELECT matricnumber FROM all_user WHERE matricnumber='$matricnumber';";
       $result = mysql_query($query);
       $anything_found = mysql_num_rows($result);


if ($anything_found>0)

{
echo "<script>alert('Hello! It Seems You've Registered Once, Just Proceed to Login...');window.location='student-login.php'</script>";

}

 

else

  {

      $lastname= $_POST['lastname'];
  $firstname= $_POST['firstname'];
  $middlename= $_POST['middlename'];
  $sex= $_POST['sex'];
  $status= $_POST['status'];
   $department= $_POST['department'];
  $level=empty($_POST['level']) ? '' : $_POST['level'];

  $matricnumber=empty($_POST['matricnumber']) ? '' : $_POST['matricnumber'];
  $password = $_POST['password'];
 
  

  $update=mysql_query("INSERT INTO all_user(lastname, firstname, middlename, sex, status, department, level, matricnumber, username, password, vote_status) VALUES ('$lastname', '$firstname','$middlename','$sex','$status','$department', '$level','$matricnumber','$matricnumber','$password', 'unvoted')");

    if($update)
                                        {
                                            echo "<script>alert('Hello! You Have Successfully Enrolled To Vote. You Can Proceed To The Voting Page.');window.location='student-login.php'</script>";
                                        }
                                        
                                       else
                                        {
                                          echo "<script>alert('Hey! It Seems Something Went Wrong');window.location='confirm_student.php'</script>";
                                        }
                                      }



                                    }
                                       ob_end_flush();
                                      ?>




<script src="js/script.js"></script>
</body>
</html>




