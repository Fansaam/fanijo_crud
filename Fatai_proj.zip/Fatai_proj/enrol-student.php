<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>
<article class="sub_body" style="background:#fff url(images/green.jpg) ;">

	<div id="top" style="z-index:1; top:0px;
    position:fixed;margin-left:190px">
		<div class="center">
			<ul>
			<li><span class='phone'><a  href="logout2.php"> Logout</a></span> </li>
				<li> <a href="#" style="font-size:17px">  </a> </li>
				<li> <a href="#" style="font-size:17px"></a> </li>
				
				<li><span class='phone'>Welcome, </span>&nbsp;  Admin </li>
			</ul>
		</div>
	</div>
	
		<br>
		<!-- navigation block  -->
		<div id="foot1">
			<div class="center">
				<ul>
				<li class="logo" style="margin-top:-35px"><img src="Images/capture.png" width="290" height="100" ></li>

					<li ><a href="#">HOME</a></li>
					
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li class= "active" > <a href="#">ADMIN</a> </li>
			<li> <a href="result.php">VIEW RESULTS</a> </li>
			
					
				</ul>
			</div>
		</div>
	<!-- end of fast blog's link block   -->
	


	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
<div id="sl_b_box">					
		
	</div>

	

	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:white;width:100%;height:300px">
						<div class="boxed">

<h2 style="margin-top:0px; height:30px; background-color:green;text-align:center;border-radius:60px;font-family:times">Enrol A New Student</h2>


</div>


<center>


 <section id="intro" class="section-intro">
      <div class="overlay2">
        <div class="container">
          <div class="main-text">
            <div class="row">
          <div class="col-sm-6 col-sm-offset-4 col-md-4 col-md-offset-4">
            <div class="page-login-form box" >
              <h3 style="color:white">
                 <br><strong style="color:black;font-size: 20px">Please Enter The Student's Matric Number And Level.</strong> <br>
              </h3>
              <form class="login-form" method="POST">
                <div class="form-group">
                  <div class="input-icon">
                    <i class="icon fa fa-user"></i>
                    <input type="text"  class="form-control" name="matricnumber" placeholder="Enter Student's Matric Number">
                  </div>
                </div> 

<br><br>
                <div class="form-group">
                  <div class="input-icon">
                    <i class="icon fa fa-user"></i>
                    <input type="text" class="form-control" placeholder="Enter Student's Level" name="level" >
                  </div>
                </div>

<br><br>
                                 
               
                 <input type="submit" class="btn btn-common log-btn" name="submit" id="submit" value="Submit">
              </form>
              
            </div>
          </div>
        </div>
           
<br>
            <!-- Start Search box -->
           
            <!-- End Search box -->
          </div>
        </div>
      </div>
    </section>













</center>
			<br>

<br>





			</div>

			
			

<?php

include('database.php');

if (isset($_POST['submit'])){

$matricnumber=$_POST['matricnumber'];
$level=$_POST['level'];


$user_query=mysql_query("select * FROM all_students WHERE matricnumber='$matricnumber'");



$count=mysql_num_rows($user_query);
$row=mysql_fetch_array($user_query);


if ($count > 0){

echo "<script>alert('The User already Exists');window.location='user-exist.php'</script>";
}


else{
 $update=mysql_query("INSERT INTO all_students(matricnumber, level) VALUES('$matricnumber', '$level')");


   echo "<script>alert('Entry Successfully Completed');window.location='admin.php'</script>";

 }
}

?>







			

				


		</div>
		
	</div>
	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li><a href="#">HOME</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li class="active"><a href="admin.php">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		<div id="foot2">
			<div class="center">				
				
			</div>
		</div>
	</footer>
<script src="js/script.js"></script>
</article>
</html>
