<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>
<article class="sub_body" style="background:#fff url(images/green.jpg)">

	<div id="top" style="z-index:1; top:0px;
    position:fixed;margin-left:190px">
		<div class="center">
			<ul>
			<li><span class='phone'><a  href="student-login.php"> Login Page</a></span> </li>
				<li> <a href="#" style="font-size:17px">  </a> </li>
				<li> <a href="#" style="font-size:17px"></a> </li>
				
				<li><span class='phone'>Welcome, </span>&nbsp; Student </li>
			</ul>
		</div>
	</div>
	
		<br>
		<!-- navigation block  -->
		<div class="center">
		<div id="logosearch" style="background-color:white;height:100px;color:green" class="wow animated zoomIn">
			<div class="logo wow animated fadeInDown"><h1><img src="Images/fuoye-logo.png" width="100" height="100"></h1></div>
			<div class="logo wow animated fadeInUp"><h1 style="margin-left:95px;margin-top:-50px;font-family:times"><strong style="font-size:40px">C</strong>omputer<br><strong style="font-size:40px">E</strong>ngineering<br><p style="font-size:15px">www.cpefuoye.com</p></h1></div>	
			
		</div>
		
		
		<!-- navigation block  -->
		<ul id="navconteiner" class="wow animated fadeInRight">			
			<li> <a href="index.php">HOME</a> </li>
			<li class="active"> <a href="student-login.php" >STUDENTS' LOGIN</a> </li>
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li> <a href="admin-login.php">ADMIN LOGIN</a> </li>
			<li> <a href="result.php">VIEW RESULTS</a> </li>
			<li> <a href="#">CONTACT US</a> </li>
		</ul>
		<!-- end of navigation  -->
	</div>	
	
	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
	<div id="sl_b_box">					
		
	</div>
	<!-- end of fast blog's link block   -->

	

	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:white;height:auto">
						<div class="boxed">

<h2 style="margin-top:0px; height:30px; background-color:green;text-align:center;border-radius:60px;font-family:times">Student Identity Confirmation Page</h2>


</div>





			<br>

<form method="post">
  <fieldset style="background-color:green;text-align:center;border-radius:60px">
 
    <br>
    
    <br>
<fieldset><legend style="color:white">Supply your Matric Number</legend>
     Matric Number:
   &nbsp;&nbsp;&nbsp; <input style="align:left;border-radius:60px;width:320px";  type="text" placeholder="Enter Your Matric Number Only" name="matricnumber"  value=""> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br>
<br>
    
      
<br>
  &nbsp;&nbsp;<input class="readmore" style="border-radius:60px;width:100px;color:green;background-color:white" type="submit" name="submit" value="Submit" style="align:center">
</fieldset>

  
    <br>
    <br>
    <br>
     <fieldset style="background-color:white;text-align:center;border-radius:60px;height:50px;color:red">

        <i>Registered Already?</i> <a  class="readmore" href="student-login.php" style="float:center;height:40px;width:130px;">Click Here To Login</a>
  </fieldset>
    <br>
    
    <br>
    <br>
    <br>
    
  </fieldset>
</form>

<br>





			</div>
			
<div class="equalcolumn" style="background-color:white;color:green;float:right;height:447px">
			<h2 style="color:green;text-align:center;font-size:25px;font-family:times">Posts You Are Required To Cast Votes For</h2>
			
				<p class="smallerp">
					 
                <fieldset style="height:350px"><legend style="text-align:center;font-size:20px"></legend>
               
                    <a  class="readmore" href="#" style="float:center;height:40px;width:130px">President</a>
                     <a  class="readmore" href="#" style="float:center;height:40px;width:130px">Vice President</a>
                      <a  class="readmore" href="#" style="float:center;height:40px;width:130px">General Secretary</a>
                   

                     
                </fieldset>
            

				</p>

			<div class="clear"></div> <br />

			<div class="clear"></div> <br /><div class="clear"></div> <br /><div class="clear"></div> <br />
			
			

				


		</div>

		
		</div>
		
	</div>





<?php
include('database.php');
    
  if(isset($_POST['submit']))
  {

   $matricnumber=$_POST['matricnumber'];


    $query = "SELECT matricnumber FROM all_students WHERE matricnumber='$matricnumber'";
       $result = mysql_query($query);
       $count = mysql_num_rows($result);

$id=$row['matricnumber'];
if ($count > 0)

{

echo "<script>alert('Welcome! Your Identity as a Computer Engineering Student has been Verified.. Please proceed with your Registration!'); window.location='register.php'</script>";


}
else
{
echo "<script>alert('Sorry! Your Identity as a Computer Engineering Student Could Not Be Verified'); window.location='index.php'</script>";

}

}
                     ?>













	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li class="active"><a href="student-login.php">STUDENTS' LOGIN</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li><a href="admin.php">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		<div id="foot2">
			<div class="center">				
				
		</div>
	</footer>
<script src="js/script.js"></script>
</article>
</html>
