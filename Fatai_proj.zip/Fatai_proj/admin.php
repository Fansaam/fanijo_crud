<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>
<article class="sub_body" style="background:#fff url(images/green.jpg) ;">

	<div id="top" style="z-index:1; top:0px;
    position:fixed;margin-left:190px">
		<div class="center">
			<ul>
			<li><span class='phone'><a  href="logout2.php"> Logout</a></span> </li>
				<li> <a href="#" style="font-size:17px">  </a> </li>
				<li> <a href="#" style="font-size:17px"></a> </li>
				
				<li><span class='phone'>Welcome, </span>&nbsp;  Admin </li>
			</ul>
		</div>
	</div>
	
		<br>
		<!-- navigation block  -->
		<div id="foot1">
			<div class="center">
				<ul>
				<li class="logo" style="margin-top:-35px"><img src="Images/capture.png" width="290" height="100" ></li>

					<li ><a href="index.php">HOME</a></li>
					
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li class= "active" > <a href="#">ADMIN</a> </li>
			<li> <a href="result.php">VIEW RESULTS</a> </li>
			
					
				</ul>
			</div>
		</div>
	<!-- end of fast blog's link block   -->
	

<div class="flex-container subpage">
	<!-- flex slider block  -->
		<div class="min_height solutions3 wow animated fadeInLeft">	
			
		</div>
	</div>
	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
	<div id="sl_b_box">					
		
	</div>

	

	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:white;width:100%;height: 200px">
						<div class="boxed">

<h2 style="margin-top:0px; height:30px; background-color:green;text-align:center;border-radius:60px;font-family:times">Welcome to Nacomes Elections Backend Session</h2>


</div>


<center>
 <fieldset style="height:100px"><legend style="text-align:center;font-size:20px"></legend>
               
                    <a  class="readmore" href="enrol-student.php" style="float:center;height:40px;width:130px">Enrol New Students</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     <a  class="readmore" href="enrolled-stud.php" style="float:center;height:40px;width:130px">View Enrolled Students</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <a  class="readmore" href="registered.php" style="float:center;height:40px;width:130px">View Registered Voters</a>
                   

                     
                </fieldset>
</center>
			<br>

<br>





			</div>


			
			





			

				


		</div>
		
	</div>
	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li><a href="#">HOME</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li class="active"><a href="admin.php">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		
			
		</div>
	</footer>
<script src="js/script.js"></script>
</article>
</html>
