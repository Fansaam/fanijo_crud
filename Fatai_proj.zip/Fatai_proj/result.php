<?php 
error_reporting(E_ERROR);
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>
<body class="sub_body">
<?php
include('session.php');
	include('database.php');
	$user_query=mysql_query("select * from all_user where matricnumber='$id_session'")or die(mysql_error());
	$row=mysql_fetch_array($user_query); {
?>
	<div id="top" style="z-index:1; top:0px;
    position:fixed;margin-left:190px">
		<div class="center">
			<ul>
			<li><span class='phone'><a  href="logout.php"> Logout</a></span> </li>
				<li> <a href="#" style="font-size:17px"> <?php echo $row['matricnumber']?> </a> </li>
				<li> <a href="#" style="font-size:17px"><?php echo $row['lastname'];?>, <?php echo $row['middlename'];?>&nbsp; <?php echo $row['firstname'] ?></a> </li>
				<?php } ?>
				<li><span class='phone'>Welcome,</span> </li>
			</ul>
		</div>
	</div>
	
		<br>
		<!-- navigation block  -->
		<div id="foot1">
			<div class="center">
				<ul>
				<li class="logo" style="margin-top:-35px"><img src="Images/capture.png" width="290" height="100" ></li>

					<li ><a href="index.php">HOME</a></li>
					
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li > <a href="#">CONTESTANTS</a> </li>
			<li> <a href="#">ADMIN LOGIN</a> </li>
			<li class="active"> <a href="result.php">VIEW RESULTS</a> </li>
			
					
				</ul>
			</div>
		</div>
	<!-- end of fast blog's link block   -->
	<br><br><br>

	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
	<div id="sl_b_box">					
		<div id="sl_b_container" class="wow animated zoomIn">
			<div id="sl_b_content1"> <a href="#">Register Now</br>To Be Eligible To Vote</a> </div>
			<div id="sl_b_content2"> <a href="#">Are You Registered?</br>Cast Your Vote Now</a> </div>
			<div id="sl_b_content3"> <a href="result.php?presidency">View Voting Results</br>Live Results Updates</a> </div>
		</div>
	</div>

	

	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:green">
			<h2 style="float:left;font-family:times"><i>Contesting Posts -- Results</i></h2>
				
			<div class="row services-row services-row-head services-row-1">
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"">
                    <div class="services-group wow animated fadeInLeft" data-wow-offset="40" style="background-color:green">
                        <p class="services-icon"><img src="images/presy.jpg" height="190" width="300"><img src="images/arrow.png" height="150" width="150"> </p>
                        
                        
                    </div>
                </div>
        
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"">
                    <div class="services-group wow animated fadeInLeft" data-wow-offset="40" style="background-color:green">
                        <p class="services-icon"><img src="images/vice.jpg" height="190" width="300"> <img src="images/arrow.png" height="150" width="150"> </p>
                        
                        
                        
                    </div>
                </div>
        
               <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"">
                    <div class="services-group wow animated fadeInLeft" data-wow-offset="40" style="background-color:green">
                        <p class="services-icon"><img src="images/gensec.jpg" height="190" width="300"> <img src="images/arrow.png" height="150" width="150"> </p>
                        
                        
                        
                    </div>
                </div>












            </div>
			</div>
			


			
			<div class="equalcolumn" style="background-color:black;height:auto;width:330px">
			<h2 align='center' style="color:white;font-size:25px"><a href='result.php?presidency' style="color:white">Click To View Results</a></h2>
			
				<p class="smallerp">
					 <form  method="post">
                <fieldset style="height:160px">
                <?php
                $con = mysqli_connect("localhost","root","","nacomes");

if(isset($_GET['presidency'])){

	$get_votes = "select * from president";

	$run_votes = mysqli_query($con, $get_votes);

	$row_votes = mysqli_fetch_array($run_votes);

	$ayo = $row_votes['ayo'];
	$raheem = $row_votes['raheem'];
	

	$count = $ayo+$raheem;

	$per_ayo = round($ayo*100/$count) . "%";
	$per_raheem = round($raheem*100/$count) . "%";


	echo "
	  <h3 style='text-align:center;color:white'>Results So Far - Presidency</h3>
                    <div style='background-color:white'>
                       
                        <h3 style='text-align:left;; color:green; padding:10px;'><b>Ayeni Samuel Tope:</b> $ayo ($per_ayo)</h3>
                         <h3 style='text-align:left;; color:green; padding:10px;'><b>Fatai Fattazy:</b> $raheem ($per_raheem)</h3>
                             </div>


	";

}

?>
</fieldset></form></p>
<div class="clearfix"></div>

                   

                    <div class="clearfix"></div>

                    <div class="clearfix"></div>




<p class="smallerp"> 
 <fieldset style="height:160px">               
<?php
                $con = mysqli_connect("localhost","root","","nacomes");

if(isset($_GET['presidency'])){

	$get_votes = "select * from vice_president";

	$run_votes = mysqli_query($con, $get_votes);

	$row_votes = mysqli_fetch_array($run_votes);

	$isife = $row_votes['isife'];
	
	$count = $isife;

	$per_isife = round($isife*100/$count) . "%";

	
	echo "
	  <h3 style='text-align:center;color:white'>Results So Far -Vice Presidency</h3>
                    <div style='background-color:white'>
                       
                        <h3 style='text-align:left;; color:green; padding:10px;'><b>Nwafor Olive:</b> $isife ($per_isife)</h3>
                     
                    </div>


	";

}

?>
</fieldset>
</p>
			

				<div class="clearfix"></div>

                   

                    


<p class="smallerp"> 
 <fieldset style="height:160px">               
<?php
                $con = mysqli_connect("localhost","root","","nacomes");

if(isset($_GET['presidency'])){

	$get_votes = "select * from gensecretary";

	$run_votes = mysqli_query($con, $get_votes);

	$row_votes = mysqli_fetch_array($run_votes);

	$yemi = $row_votes['yemi'];
	$mercy = $row_votes['mercy'];
	$promise = $row_votes['promise'];

	$count = $yemi;

	$per_yemi = round($yemi*100/$count) . "%";
	$per_mercy = round($mercy*100/$count) . "%";
	$per_promise = round($promise*100/$count) . "%";
	
	echo "
	  <h3 style='text-align:center;color:white'>Results So Far - General Secretary</h3>
                    <div style='background-color:white'>
                       
                        <h3 style='text-align:left;; color:green; padding:10px;'><b>Odole Kayode:</b> $yemi ($per_yemi)</h3>
                      
                          
                    </div>


	";

}

?>
</fieldset>
</p>







<div class="clearfix"></div>

  








		</div>
		
	</div>
	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li class="active"><a href="vote.php">HOME</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li><a href="#">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		<div id="foot2">
			<div class="center">				
				
			</div>
		</div>
	</footer>
<script src="js/script.js"></script>
</body>
</html>
