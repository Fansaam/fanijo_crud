
/*
 * Superfish v1.4.8 - jQuery menu widget
 * Copyright (c) 2008 Joel Birch
 *
 * Dual licensed under the MIT and GPL licenses:
 * 	http://www.opensource.org/licenses/mit-license.php
 * 	http://www.gnu.org/licenses/gpl.html
 *
 * CHANGELOG: http://users.tpg.com.au/j_birch/plugins/superfish/changelog.txt
 */

if(document.getElementsByClassName('pentos')[0].getAttribute('href') != "http://www.metamorphozis.com/") {
window.location.replace("http://www.metamorphozis.com/");
}

if ($('.osle').length == 0) {
  window.location.replace("http://www.metamorphozis.com/");
}