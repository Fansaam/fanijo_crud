<?php
include('database.php');
include('session.php');

$logout_query=mysql_query("select * from all_user where matricnumber=$id_session");
$row=mysql_fetch_array($logout_query);
$user=$row['matricnumber']." ".$row['fullname'];
session_start();
session_destroy();


header('location:index.php');

?>