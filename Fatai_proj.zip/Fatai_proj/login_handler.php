<?php
include('database.php');

if (isset($_POST['login'])){

$matricnumber=$_POST['matricnumber'];
$password=$_POST['password'];

$login_query=mysql_query("select * from all_user where matricnumber='$matricnumber' and password='CPE'");

$login_query2=mysql_query("select * from all_user where matricnumber='$matricnumber' and vote_status='voted'");
$voted=mysql_num_rows($login_query2);

$count=mysql_num_rows($login_query);
$row=mysql_fetch_array($login_query);
$matricnumber=$row['matricnumber'];
$password=$row['password'];

if ($voted == 1) {
echo "<script>alert('You Cannot Vote More than Once'); window.location='index.php'</script>";
}
else
if ($count > 0){
session_start();
$_SESSION['id']=$row['matricnumber'];
$user=$row['matricnumber']." ".$row['lastname'];



echo "<script>alert('You Have Been Successfully Logged-In!'); window.location='vote.php'</script>";
}


else{
    echo "<script>alert('Invalid Username and Password! Try again.'); window.location='index.php'</script>";
?>
<?php }
}
?>