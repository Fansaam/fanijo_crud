<?php 
require 'database.php';
$ID=$_GET['matricnumber'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>


<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 7px;
    
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>



<article class="sub_body" style="background:#fff url(images/green.jpg)">

	<div id="top" style="z-index:1; top:0px;
    position:fixed;margin-left:190px">
		<div class="center">
			<ul>
			<li><span class='phone'><a  href="logout2.php"> Logout</a></span> </li>
				<li> <a href="#" style="font-size:17px">  </a> </li>
				<li> <a href="#" style="font-size:17px"></a> </li>
				
				<li><span class='phone'>Welcome, </span>&nbsp;  Admin </li>
			</ul>
		</div>
	</div>
	
		<br>
		<!-- navigation block  -->
		<div id="foot1">
			<div class="center">
				<ul>
				<li class="logo" style="margin-top:-35px"><img src="Images/capture.png" width="290" height="100" ></li>

					<li ><a href="#">HOME</a></li>
					
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li class= "active" > <a href="#">ADMIN</a> </li>
			<li> <a href="result.php">VIEW RESULTS</a> </li>
			
					
				</ul>
			</div>
		</div>
	<!-- end of fast blog's link block   -->
	

	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
	<div id="sl_b_box">					
		
	</div>

	

	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:white;height:auto;width:100%">
						<div class="boxed">

<h2 style="margin-top:0px; height:30px; background-color:green;text-align:center;border-radius:60px;font-family:times">Edit Registered Students</h2>


</div>



 <section id="intro" class="section-intro">
      <div class="overlay22">
        <div class="container">
          <div class="main-text">
            <div class="row">
    <div class="box col-md-12">
        <div class="box-inner">
            <div class="box-header well" data-original-title="">


<?php
  $query=mysql_query("select * from all_user where matricnumber='$ID'")or die(mysql_error());
$row=mysql_fetch_array($query);
  ?>

                <h2 style="color:green;text-align: center"><i class="glyphicon glyphicon-user"></i>Edit and Update <?php echo $row ['firstname'];?>'s</strong> Details </h2>

               
            </div>
            <div class="box-content" style="width: ">
                <!-- Start content here -->
				
					

<?php
  $query=mysql_query("select * from all_user where matricnumber='$ID'")or die(mysql_error());
$row=mysql_fetch_array($query);
  ?>					<center>
					<form method="post" enctype="multipart/form-data" class="form-horizontal" style="color:green;font-size: 16px">
					  
					  <div class="form-group">
						<label for="inputEmail3" class="col-sm-2 control-label">LastName</label>
						<div class="col-sm-4">
						  <input type="text" name="lastname" value="<?php echo $row['lastname']; ?>" class="form-control" id="inputEmail3" placeholder="Last Name" />
						</div>
						<span style="color:red;"></span>
					  </div><br>

					  <div class="form-group">
						<label for="inputEmail3" class="col-sm-2 control-label">Middlename</label>
						<div class="col-sm-4">
						  <input type="text" name="middlename" value="<?php echo $row['middlename']; ?>" class="form-control" id="inputEmail3" placeholder="Firstname" required />
						</div>
					  </div>
<br>
					  <div class="form-group">
						<label for="inputEmail3" class="col-sm-2 control-label">Firstname</label>
						<div class="col-sm-4">
						  <input type="text" name="firstname" value="<?php echo $row['firstname']; ?>" class="form-control" id="inputEmail3" placeholder="Firstname" required />
						</div>
					  </div>

		<br>			 
					  
					  <div class="form-group">
						<label for="inputPassword3" class="col-sm-2 control-label">Matric Number</label>
						<div class="col-sm-4">
						  <input type="text" name="matricnumber" value="<?php echo $row['matricnumber']; ?>" class="form-control" id="inputPassword3" placeholder="Username" required />
						</div>
					  </div>
<br>
					   <div class="form-group">
						<label for="inputEmail3" class="col-sm-2 control-label">Level</label>
						<div class="col-sm-4">
						  <input type="text" name="level" value="<?php echo $row['level']; ?>" class="form-control" id="inputEmail3" placeholder="Firstname" required />
						</div>
					  </div>
<br>
					  <div class="form-group">
						<label for="inputPassword3" class="col-sm-2 control-label">Password</label>
						<div class="col-sm-4">
						  <input type="text" name="password" value="<?php echo $row['password']; ?>" class="form-control" id="inputPassword3" placeholder="Password" required />
						</div>
					  </div>
					  <br><br>
					  <div class="form-group">
						<label for="inputPassword3" class="col-sm-2 control-label"></label>
						<div class="col-sm-7">
						  <button type="submit" name="update" class="btn btn-primary" style="background-color: green;color:white"><i class="glyphicon glyphicon-save"></i> Update</button>
						</div>
					  </div>
					</form>
							
<?php
$ID =$_GET['matricnumber'];
if (isset($_POST['update'])) {

						$lastname= $_POST['lastname'];
      $middlename= $_POST['middlename'];
  $firstname= $_POST['firstname'];
  
 
   $matricnumber=empty($_POST['matricnumber']) ? '' : $_POST['matricnumber'];
    $level=empty($_POST['level']) ? '' : $_POST['level'];
  $password=empty($_POST['password']) ? '' : $_POST['password'];


mysql_query("UPDATE all_user SET lastname='$lastname', middlename='$middlename', firstname='$firstname', matricnumber='$matricnumber', level='$level', password='$password' WHERE matricnumber = '$ID' ")or die(mysql_error());

header('location:registered.php');

}



?>

<br>





			</div>




			

				


		</div>
		
	</div>
</div></div></section>
	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li><a href="#">HOME</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li class="active"><a href="admin.php">ADMIN</a></li>
					
				</ul>
			</div>
		</div>
		
	</footer>
<script src="js/script.js"></script>
</article>
</html>
