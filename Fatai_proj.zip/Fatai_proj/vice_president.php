<?php require('logged_header.php');?>




 <div class="page-header" style="background: url(assets/img/votekeyboard.jpg);"><br><br><br><br><br><br><br><br><br><br><br>
      <div class="container">
        <div class="row">         
          <div class="col-md-12">
            <div class="breadcrumb-wrapper">
              <h2  style="margin-top:-140px;font-size:45px;color:white"><i>Welcome To The Voting Section</i></h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Page Header End --> 

    <!-- Content section Start --> 
    <section >
   <div class="features">
        <div class="container">
        <form method="POST">
          <div class="row">
           <h3 class="section-title">SECTION 2 - VICE PRESIDENT</h3>
            <div class="col-md-6 col-sm-6">
              <div class="features-box wow fadeInDownQuick" data-wow-delay="0.3s">
                <div class="features-icon">
                  <img src="assets/img/product/isife.jpg" height="220" width="200">
                </div>

                <div class="features-content">
                  <h4>
                    Name: Isife OlisaEmeka Fredrick
                  </h4>
                  <p>
                   Level: 400Level<br> Vying For: Vice President
                  </p><br><br><br>
                   <input type="submit" class="btn btn-common log-btn" name="isife" value="Vote Isife" style="width:150px">
                </div>
              </div>
            </div>
             <div class="col-md-6 col-sm-6">
              <div class="features-box wow fadeInDownQuick" data-wow-delay="0.6s">
                <div class="features-icon">
                  <img src="assets/img/product/gbenga.jpg" height="220" width="200">
                </div>

                <div class="features-content">
                  <h4>
                    Name: Olufeyimi Olugbenga Olatunde
                  </h4>
                  <p>
                   Level: 400Level<br> Vying For: Vice President
                  </p><br><br><br>
                   <input type="submit" class="btn btn-common log-btn" name="gbenga" value="Vote Gbenga" style="width:150px">
                </div>
              </div>
            </div>




          </div>
          </form>
        </div>
      </div>
    </section>
    <!-- Content section End --> 
    





<?php


$con = mysqli_connect("localhost","root","","nacomes");



if(isset($_POST['isife']))

{
    $query = "SELECT matricnumber FROM vice_presidency  WHERE matricnumber='$id_session'";
       $result = mysql_query($query);
       $anything_found = mysql_num_rows($result);
  if ($anything_found)

    {
$URL="voted_p.php";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";

}
else{
 $vote_isife = "UPDATE vice_president set isife=isife+1";
$update=mysql_query("INSERT INTO vice_presidency(matricnumber, voted_candidate)VALUES('$id_session','Isife OlisaEmeka Fredrick')");
$update2=mysql_query("INSERT INTO isife(matricnumber)VALUES('$id_session')");
  $run_isife = mysqli_query($con, $vote_isife);
  
  

  $URL="success_v.php";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";


  
}
}





if(isset($_POST['gbenga']))

{
   $query = "SELECT matricnumber FROM vice_presidency WHERE matricnumber='$id_session'";
       $result = mysql_query($query);
       $anything_found = mysql_num_rows($result);
  if ($anything_found)

    {
$URL="voted_p.php";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";

}
else{
 $vote_gbenga = "UPDATE vice_president set gbenga=gbenga+1";
$update=mysql_query("INSERT INTO vice_presidency(matricnumber, voted_candidate)VALUES('$id_session', 'Olufeyimi Olugbenga Olatunde')");
$update2=mysql_query("INSERT INTO gbenga(matricnumber)VALUES('$id_session')");
  $run_gbenga = mysqli_query($con, $vote_gbenga);

   $URL="success_p.php";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";

}
}







?>



<?php require('footer.php');?>