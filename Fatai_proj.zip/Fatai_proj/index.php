﻿<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>
<article class="sub_body" style="background:#fff url(images/green.jpg)">

	<div id="top">
		<div class="center">
			<ul>
				<li> <a href="confirm_student.php">Register</a> </li>
				<li> <a href="student-login.php">Log In</a> </li>
				
			</ul>
		</div>
	</div>
	<div class="center">
		<div id="logosearch" style="background-color:white;height:100px;color:green" class="wow animated zoomIn">
			<div class="logo wow animated fadeInDown"><h1><img src="Images/fuoye-logo.png" width="100" height="100"></h1></div>
			<div class="logo wow animated fadeInUp"><h1 style="margin-left:95px;margin-top:-50px;font-family:times"><strong style="font-size:40px">C</strong>omputer<br><strong style="font-size:40px">E</strong>ngineering<br><p style="font-size:15px">www.cpefuoye.com</p></h1></div>	
			
		</div>
		
		
		<!-- navigation block  -->
		<ul id="navconteiner" class="wow animated fadeInRight">			
			<li class ="active"> <a href="index.php">HOME</a> </li>
			<li> <a href="confirm_student.php" >REGISTER</a> </li>
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li> <a href="admin-login.php">ADMIN LOGIN</a> </li>
			<li> <a href="result.php">VIEW RESULTS</a> </li>
			<li> <a href="#">CONTACT US</a> </li>
		</ul>
		<!-- end of navigation  -->
	</div>	
	<div class="flex-container subpage">
	<!-- flex slider block  -->
		<div class="min_height solutions wow animated fadeInLeft">	
			<h6 class="wow animated zoomIn" style="color:green;font-size:27px;float:right;margin-top:-50px;font-family:times">Welcome To The Student Online Voting Platform<br>Department Of Computer Engineering<br><strong style="font-size:35px" class="wow animated fadeInRight">Federal University Oye-Ekiti</strong></h6>
		</div>
	</div>
	<!-- end of flex slider block  -->
	<!-- fast blog's link block   -->
	<div id="sl_b_box">					
		<div id="sl_b_container" class="wow animated zoomIn">
			<div id="sl_b_content1"> <a href="confirm_student.php">Register Now</br>To Be Eligible To Vote</a> </div>
			<div id="sl_b_content2"> <a href="vote.php">Are You Registered?</br>Cast Your Vote Now</a> </div>
			<div id="sl_b_content3"> <a href="result.php">View Voting Results</br>Live Results Updates</a> </div>
		</div>
	</div>
	<!-- end of fast blog's link block   -->
	
	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:green;">
			<h2>Know More About The Contestants</h2>
				
			<img src="images/president.jpg" width="250" height="150" alt="President"/>
			<div class="smallerp">
				<p style="font-size:16px">
					<strong style="font-size:23px"><a href="#" style=" color:white">
						For The Post Of President</a>
					</strong>
					- Ayeni Samuel<br>
					- Fatai<br>
					
				</p>
			</div>
			<div class="clear"></div> <br />
			
			<img src="images/vote1.jpg" width="250" height="150" alt="Vice-President"/>
			<div class="smallerp">
				<p style="font-size:16px">
					<strong style="font-size:23px"><a href="#" style=" color:white">
						For The Post Of Vice-President</a>
					</strong>
					- Nwafor Olive
					
				</p>
			</div>
			<div class="clear"></div> <br />
			
			<img src="images/vote2.jpg" width="250" height="150" alt="General Secretary"/>
			<div class="smallerp">
				<p style="font-size:16px">
					<strong style="font-size:23px"><a href="#" style=" color:white">
						For The Post Of General Secretary</a>
					</strong>
					- Odole Kayode
					
		</p>
	</div>



		</div>
		
		<div class="equalcolumn" style="background-color:white;color:green;height:600px;width:330px">
			
			
				<p class="smallerp">
					 <form  method="post">
                <fieldset style="height:180px"><legend style="text-align:center"><h2 style="color:green;text-align:center">Cast Your Votes</h2></legend>
                <h3 style="text-align:center;color:green;font-size:19px"><strong style="color:red;font-size:23px">NOTE:</strong> Your Matric Number Is Your Username</h3><br>
                     <a  class="readmore" href="student-login.php" style="margin-left: 20px; align:center;float:center;height:40px;width:260px;font-size:20px;text-align:center">Click Here To LOGIN</a>
                   
                    </p>
                </fieldset>
            </form>

				</p>

			<div class="clear"></div>

			<div class="clear"></div> <div class="clear"></div> <br /><div class="clear"></div> 
			<h2 style="color:green">About Nacomes</h2>
			<img src="images/cpelogo.jpg" width="250" height="150" alt=""/>
				<p class="smallerp" style="font-size:15px;color:green">
					Nacomes, an acronym which stands for "National Association Of Computer Engineering Student" is an official student association whose sole aim is to help unify students together, most importantly socially and academically...
					<a class="readmore" href="#">Read More</a>
				</p>

				

				


		</div>
		
	</div>
	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li class="active"><a href="index.php">HOME</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li><a href="admin-login.php">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		<div id="foot2">
			<div class="center">				
				
			</div>
		</div>
	</footer>








<script src="js/script.js"></script>
</body>
</html>
