
<?php
  ob_start();
  include('database.php');
  
  if(isset($_GET['matricnumber'])!="")
  {
  $delete=$_GET['matricnumber'];
  $delete2=mysql_query("DELETE FROM all_user WHERE matricnumber='$delete'");
  if($delete2)
  {
    echo "<script>alert('You Have Successfully Deleted The Selected Student Record');window.location='registered.php'</script>";

  }
  else
  {
    echo "<script>alert('Hey, It Seems Something Went Wrong. Record Could Not Be Deleted');window.location='user.php'</script>";
      echo mysql_error();
  }
  }
  ob_end_flush();
?>
