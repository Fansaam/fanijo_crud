<?php
include('database.php');
include('session.php');

$logout_query=mysql_query("select * from admin where username=$id_session");
$row=mysql_fetch_array($logout_query);
$user=$row['username']." ".$row['username'];
session_start();
session_destroy();

header('location:index.php');

?>