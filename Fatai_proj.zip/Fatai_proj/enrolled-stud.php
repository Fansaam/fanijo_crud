<!DOCTYPE html>
<html lang="en">
<head>
<title>CPE Online Voting System</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/normalize.css" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
 <link rel="stylesheet" href="css/animate.min.css">
</head>


<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 7px;
    
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>


<article class="sub_body" style="background:#fff url(images/green.jpg) ;">

	<div id="top" style="z-index:1; top:0px;
    position:fixed;margin-left:190px">
		<div class="center">
			<ul>
			<li><span class='phone'><a  href="logout2.php"> Logout</a></span> </li>
				<li> <a href="#" style="font-size:17px">  </a> </li>
				<li> <a href="#" style="font-size:17px"></a> </li>
				
				<li><span class='phone'>Welcome, </span>&nbsp;  Admin </li>
			</ul>
		</div>
	</div>
	
		<br>
		<!-- navigation block  -->
		<div id="foot1">
			<div class="center">
				<ul>
				<li class="logo" style="margin-top:-35px"><img src="Images/capture.png" width="290" height="100" ></li>

					<li ><a href="#">HOME</a></li>
					
			<li>
				<a href="#">NACOMES</a>
				
			</li>
			<li> <a href="#">CONTESTANTS</a> </li>
			<li class= "active" > <a href="#">ADMIN</a> </li>
			<li> <a href="result.php">VIEW RESULTS</a> </li>
			
					
				</ul>
			</div>
		</div>
	<!-- end of fast blog's link block   -->
	


	<div id="sl_b_box">					
		
	</div>

	

	<!-- main content block   -->	
	<div class="center clearfix">				

		<div class="equalcolumn span_600" style="background-color:white;height:auto;width:100%">
						<div class="boxed">

<h2 style="margin-top:0px; height:30px; background-color:green;text-align:center;border-radius:60px;font-family:times">Enrolled Students Page</h2>


</div>



 <table style="color:black">
         
          <tr>
            <th style="text-align: center;">Matric Number</th>
            <th style="text-align:center">Level</th>
            
            <th style="text-align:center; ">Actions</th>

          </tr>
         
          
              <?php
              require 'database.php';
              $result= mysql_query("SELECT * FROM all_students order by matricnumber") or die (mysql_error());
              while ($row= mysql_fetch_array ($result) ){
              $id=$row['matricnumber'];
              ?>
          <tr>
            <td style="text-align: center;"><?php echo $row['matricnumber']; ?></td>
                        <td style="text-align: center;"><?php echo $row['level']; ?></td>
                        

            <td class="" style="text-align: center;">
              <!--<a class="btn btn-success" href="#">
                <i class="glyphicon glyphicon-zoom-in icon-white"></i>
                View
              </a>-->
            <a class="readmore" href="delete_user_query2.php<?php echo '?matricnumber='.$id; ?>" onclick="return confirm('Are you sure you want to delete this Student Record?');" style="height:40px;width:130px;background-color: red;text-align: center;">Delete</a>

           
            </td>

              <?php } ?>

                            </tr>



          </tbody>
          </table>
			<br>

<br>





			</div>
	

			
			

<?php

include('database.php');

if (isset($_POST['submit'])){

$matricnumber=$_POST['matricnumber'];
$level=$_POST['level'];


$user_query=mysql_query("select * FROM all_students WHERE matricnumber='$matricnumber'");



$count=mysql_num_rows($user_query);
$row=mysql_fetch_array($user_query);


if ($count > 0){

echo "<script>alert('The User already Exists');window.location='user-exist.php'</script>";
}


else{
 $update=mysql_query("INSERT INTO all_students(matricnumber, level) VALUES('$matricnumber', '$level')");


   echo "<script>alert('Entry Successfully Completed');window.location='admin.php'</script>";

 }
}

?>







			

				


		</div>
		
	</div>
	<!-- end of main content block   --><!-- Do not remove -->
	
	<!-- end -->
	<footer>
		<div id="foot1">
			<div class="center">
				<ul>
					<li><a href="#">HOME</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">NACOMES</a></li>
					<li><a href="#">CONTESTANTS</a></li>
					<li class="active"><a href="admin.php">ADMIN</a></li>
					<li><a href="#">CONTACT US</a></li>
				</ul>
			</div>
		</div>
		<div id="foot2">
			<div class="center">				
				
			</div>
		</div>
	</footer>
<script src="js/script.js"></script>
</article>
</html>
