<?php
ob_start();
mysql_select_db('nacomes',mysql_connect('localhost','root',''))or die(mysql_error());
?>