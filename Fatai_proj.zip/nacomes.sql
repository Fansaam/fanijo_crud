-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2018 at 10:49 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nacomes`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `fullname`) VALUES
(1, 'fansam', 'fansam', 'Engr. Fansam'),
(2, 'fatai', 'fatai', 'Fatai');

-- --------------------------------------------------------

--
-- Table structure for table `all_students`
--

CREATE TABLE IF NOT EXISTS `all_students` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL,
  `level` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_students`
--

INSERT INTO `all_students` (`id`, `matricnumber`, `level`) VALUES
(13, 'CPE/13/1077', '500 Level'),
(14, 'CPE/13/1076', '400 Level'),
(19, 'CPE/14/1885', '400Level'),
(22, 'CPE/13/1075', '500Level');

-- --------------------------------------------------------

--
-- Table structure for table `all_user`
--

CREATE TABLE IF NOT EXISTS `all_user` (
  `user_id` int(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `level` varchar(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL,
  `username` varchar(3) NOT NULL,
  `password` varchar(100) NOT NULL,
  `vote_status` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_user`
--

INSERT INTO `all_user` (`user_id`, `lastname`, `firstname`, `middlename`, `sex`, `status`, `department`, `level`, `matricnumber`, `username`, `password`, `vote_status`) VALUES
(5, 'Ayeni', 'Samuel', 'S', 'Male', 'Student', 'Computer Engineering', '500Level', 'CPE/13/1075', 'CPE', 'AYENI', 'unvoted');

-- --------------------------------------------------------

--
-- Table structure for table `ayo`
--

CREATE TABLE IF NOT EXISTS `ayo` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gbenga`
--

CREATE TABLE IF NOT EXISTS `gbenga` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gensec`
--

CREATE TABLE IF NOT EXISTS `gensec` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL,
  `voted_candidate` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gensec`
--

INSERT INTO `gensec` (`id`, `matricnumber`, `voted_candidate`) VALUES
(1, 'CPE/13/1075', 'Odole Kayode');

-- --------------------------------------------------------

--
-- Table structure for table `gensecretary`
--

CREATE TABLE IF NOT EXISTS `gensecretary` (
  `yemi` int(100) NOT NULL,
  `mercy` int(100) NOT NULL,
  `promise` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gensecretary`
--

INSERT INTO `gensecretary` (`yemi`, `mercy`, `promise`) VALUES
(1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `isife`
--

CREATE TABLE IF NOT EXISTS `isife` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `isife`
--

INSERT INTO `isife` (`id`, `matricnumber`) VALUES
(1, 'CPE/13/1075');

-- --------------------------------------------------------

--
-- Table structure for table `presidency`
--

CREATE TABLE IF NOT EXISTS `presidency` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL,
  `voted_candidate` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `presidency`
--

INSERT INTO `presidency` (`id`, `matricnumber`, `voted_candidate`) VALUES
(1, 'CPE/13/1075', 'Fatai Fattazy');

-- --------------------------------------------------------

--
-- Table structure for table `president`
--

CREATE TABLE IF NOT EXISTS `president` (
  `ayo` int(100) NOT NULL,
  `raheem` int(100) NOT NULL,
  `joshua` int(100) NOT NULL,
  `samuel` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `president`
--

INSERT INTO `president` (`ayo`, `raheem`, `joshua`, `samuel`) VALUES
(1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pro`
--

CREATE TABLE IF NOT EXISTS `pro` (
  `timi` int(100) NOT NULL,
  `falokun` int(100) NOT NULL,
  `tunji` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pro_votes`
--

CREATE TABLE IF NOT EXISTS `pro_votes` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL,
  `voted_candidate` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pro_votes`
--

INSERT INTO `pro_votes` (`id`, `matricnumber`, `voted_candidate`) VALUES
(2, 'CPE/12/0885', 'Falokun Oladeji Christopher'),
(3, 'CPE/12/0886', 'Olaleye Timilehin'),
(4, 'CPE/12/0883', 'Olaleye Timilehin'),
(5, 'CPE/13/1077', 'Olaleye Timilehin'),
(6, 'CPE/12/0892', 'Falokun Oladeji Christopher'),
(7, 'CPE/12/0891', 'Olaleye Timilehin');

-- --------------------------------------------------------

--
-- Table structure for table `raheem`
--

CREATE TABLE IF NOT EXISTS `raheem` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `raheem`
--

INSERT INTO `raheem` (`id`, `matricnumber`) VALUES
(1, 'CPE/13/1075');

-- --------------------------------------------------------

--
-- Table structure for table `vice_presidency`
--

CREATE TABLE IF NOT EXISTS `vice_presidency` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL,
  `voted_candidate` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vice_presidency`
--

INSERT INTO `vice_presidency` (`id`, `matricnumber`, `voted_candidate`) VALUES
(1, 'CPE/13/1075', 'Nwafor Olive');

-- --------------------------------------------------------

--
-- Table structure for table `vice_president`
--

CREATE TABLE IF NOT EXISTS `vice_president` (
  `isife` int(100) NOT NULL,
  `gbenga` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vice_president`
--

INSERT INTO `vice_president` (`isife`, `gbenga`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `yemi`
--

CREATE TABLE IF NOT EXISTS `yemi` (
  `id` int(100) NOT NULL,
  `matricnumber` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `yemi`
--

INSERT INTO `yemi` (`id`, `matricnumber`) VALUES
(1, 'CPE/13/1075');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `all_students`
--
ALTER TABLE `all_students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `all_user`
--
ALTER TABLE `all_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `ayo`
--
ALTER TABLE `ayo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gbenga`
--
ALTER TABLE `gbenga`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gensec`
--
ALTER TABLE `gensec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gensecretary`
--
ALTER TABLE `gensecretary`
  ADD PRIMARY KEY (`yemi`);

--
-- Indexes for table `isife`
--
ALTER TABLE `isife`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `presidency`
--
ALTER TABLE `presidency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `president`
--
ALTER TABLE `president`
  ADD PRIMARY KEY (`ayo`);

--
-- Indexes for table `pro`
--
ALTER TABLE `pro`
  ADD PRIMARY KEY (`timi`);

--
-- Indexes for table `pro_votes`
--
ALTER TABLE `pro_votes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `raheem`
--
ALTER TABLE `raheem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vice_presidency`
--
ALTER TABLE `vice_presidency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vice_president`
--
ALTER TABLE `vice_president`
  ADD PRIMARY KEY (`isife`);

--
-- Indexes for table `yemi`
--
ALTER TABLE `yemi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `all_students`
--
ALTER TABLE `all_students`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `all_user`
--
ALTER TABLE `all_user`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `ayo`
--
ALTER TABLE `ayo`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gbenga`
--
ALTER TABLE `gbenga`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gensec`
--
ALTER TABLE `gensec`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `isife`
--
ALTER TABLE `isife`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `presidency`
--
ALTER TABLE `presidency`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pro`
--
ALTER TABLE `pro`
  MODIFY `timi` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pro_votes`
--
ALTER TABLE `pro_votes`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `raheem`
--
ALTER TABLE `raheem`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vice_presidency`
--
ALTER TABLE `vice_presidency`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `yemi`
--
ALTER TABLE `yemi`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
