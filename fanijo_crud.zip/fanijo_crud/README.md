## MY CRUD APPLICATION ##

**THIS CRUD APPLICATION** is a simple web application which performs CRUD functionalities using NodeJS, ExpressJS and MongoDB for Backend; while the Front end is developed using AngularJS


## Usage ##
1.Clone or download 
2.Run **npm install**
3.Ensure to connect to the **MongoDB** and Start **Mongo Shell** 
4.Run **node app** to execute the application
5.Go to your web browser and type **Localhost:3000** and run.



